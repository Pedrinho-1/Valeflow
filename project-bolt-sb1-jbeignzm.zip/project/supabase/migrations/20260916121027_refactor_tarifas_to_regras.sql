/*
# Refatorar tarifas para regras de valores

## Objetivo
A tabela `tarifas` passa a suportar regras de tarifa independentes de linhas de ônibus.
Os campos antigos são mantidos para preservar dados existentes, mas deixam de ser
obrigatórios para novos cadastros.

## Novas colunas
- `regra_nome`: nome da regra ou categoria da tarifa.
- `trechos_diarios`: quantidade padrão de trechos por dia.
- `valor_diario_override`: valor diário fixo opcional que substitui a multiplicação.

## Alterações compatíveis
- `codigo_linha`, `descricao` e `concessionaria` deixam de ser obrigatórios.
- Registros existentes recebem uma regra baseada na descrição/código e 2 trechos diários.
- Nenhuma coluna ou dado existente é removido.

## Segurança
- Nenhuma alteração nas políticas RLS existentes.
*/

ALTER TABLE tarifas ADD COLUMN IF NOT EXISTS regra_nome text;
ALTER TABLE tarifas ADD COLUMN IF NOT EXISTS trechos_diarios integer NOT NULL DEFAULT 2;
ALTER TABLE tarifas ADD COLUMN IF NOT EXISTS valor_diario_override numeric;

ALTER TABLE tarifas ALTER COLUMN codigo_linha DROP NOT NULL;
ALTER TABLE tarifas ALTER COLUMN descricao DROP NOT NULL;
ALTER TABLE tarifas ALTER COLUMN concessionaria DROP NOT NULL;

UPDATE tarifas
SET regra_nome = COALESCE(NULLIF(descricao, ''), NULLIF(codigo_linha, ''), 'Tarifa padrão')
WHERE regra_nome IS NULL;

UPDATE tarifas
SET trechos_diarios = 2
WHERE trechos_diarios IS NULL OR trechos_diarios < 1;
