/*
# Transport Control System - Database Schema

1. New Tables
- `vehicles` — registered transport vehicles (trucks, vans, etc.)
  - id (uuid PK), plate (text unique), model (text), brand (text), year (int), 
    capacity_kg (numeric), fuel_type (text), status (text: active/inactive/maintenance),
    created_at (timestamptz)
- `drivers` — registered drivers
  - id (uuid PK), name (text), license_number (text unique), phone (text),
    email (text), status (text: active/inactive), hire_date (date), created_at (timestamptz)
- `routes` — delivery/transport routes
  - id (uuid PK), name (text), origin (text), destination (text),
    distance_km (numeric), estimated_hours (numeric), status (text: active/inactive),
    created_at (timestamptz)
- `trips` — individual trips assigned to drivers and vehicles on routes
  - id (uuid PK), vehicle_id (uuid FK), driver_id (uuid FK), route_id (uuid FK),
    departure_date (timestamptz), arrival_date (timestamptz),
    status (text: scheduled/in_transit/completed/cancelled),
    cargo_description (text), cargo_weight_kg (numeric),
    notes (text), created_at (timestamptz)
- `maintenance_records` — vehicle maintenance log
  - id (uuid PK), vehicle_id (uuid FK), maintenance_date (date),
    type (text: preventive/corrective/inspection), description (text),
    cost (numeric), mechanic (text), status (text: scheduled/in_progress/completed),
    created_at (timestamptz)

2. Security
- RLS enabled on all tables.
- Single-tenant app (no auth): policies allow anon + authenticated full CRUD.
- All data is intentionally shared/public within the app.
*/

CREATE TABLE IF NOT EXISTS vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plate text UNIQUE NOT NULL,
  model text NOT NULL,
  brand text NOT NULL,
  year int NOT NULL,
  capacity_kg numeric NOT NULL DEFAULT 0,
  fuel_type text NOT NULL DEFAULT 'diesel',
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_vehicles" ON vehicles;
CREATE POLICY "anon_select_vehicles" ON vehicles FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_vehicles" ON vehicles;
CREATE POLICY "anon_insert_vehicles" ON vehicles FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_vehicles" ON vehicles;
CREATE POLICY "anon_update_vehicles" ON vehicles FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_vehicles" ON vehicles;
CREATE POLICY "anon_delete_vehicles" ON vehicles FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS drivers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  license_number text UNIQUE NOT NULL,
  phone text,
  email text,
  status text NOT NULL DEFAULT 'active',
  hire_date date,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE drivers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_drivers" ON drivers;
CREATE POLICY "anon_select_drivers" ON drivers FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_drivers" ON drivers;
CREATE POLICY "anon_insert_drivers" ON drivers FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_drivers" ON drivers;
CREATE POLICY "anon_update_drivers" ON drivers FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_drivers" ON drivers;
CREATE POLICY "anon_delete_drivers" ON drivers FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS routes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  origin text NOT NULL,
  destination text NOT NULL,
  distance_km numeric NOT NULL DEFAULT 0,
  estimated_hours numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE routes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_routes" ON routes;
CREATE POLICY "anon_select_routes" ON routes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_routes" ON routes;
CREATE POLICY "anon_insert_routes" ON routes FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_routes" ON routes;
CREATE POLICY "anon_update_routes" ON routes FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_routes" ON routes;
CREATE POLICY "anon_delete_routes" ON routes FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS trips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id uuid REFERENCES vehicles(id) ON DELETE SET NULL,
  driver_id uuid REFERENCES drivers(id) ON DELETE SET NULL,
  route_id uuid REFERENCES routes(id) ON DELETE SET NULL,
  departure_date timestamptz,
  arrival_date timestamptz,
  status text NOT NULL DEFAULT 'scheduled',
  cargo_description text,
  cargo_weight_kg numeric NOT NULL DEFAULT 0,
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE trips ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_trips" ON trips;
CREATE POLICY "anon_select_trips" ON trips FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_trips" ON trips;
CREATE POLICY "anon_insert_trips" ON trips FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_trips" ON trips;
CREATE POLICY "anon_update_trips" ON trips FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_trips" ON trips;
CREATE POLICY "anon_delete_trips" ON trips FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS maintenance_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id uuid REFERENCES vehicles(id) ON DELETE SET NULL,
  maintenance_date date NOT NULL,
  type text NOT NULL DEFAULT 'preventive',
  description text NOT NULL,
  cost numeric NOT NULL DEFAULT 0,
  mechanic text,
  status text NOT NULL DEFAULT 'scheduled',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE maintenance_records ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_maintenance" ON maintenance_records;
CREATE POLICY "anon_select_maintenance" ON maintenance_records FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_maintenance" ON maintenance_records;
CREATE POLICY "anon_insert_maintenance" ON maintenance_records FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_maintenance" ON maintenance_records;
CREATE POLICY "anon_update_maintenance" ON maintenance_records FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_maintenance" ON maintenance_records;
CREATE POLICY "anon_delete_maintenance" ON maintenance_records FOR DELETE
  TO anon, authenticated USING (true);
