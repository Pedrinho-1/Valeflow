/*
# Adicionar coluna municipio à tabela funcionarios

## Changes
- Adiciona coluna `municipio` (text, nullable) à tabela `funcionarios`.
- Permite armazenar o município informado na planilha para cruzamento de tarifas.

## Security
- Sem mudanças em RLS.
*/

ALTER TABLE funcionarios ADD COLUMN IF NOT EXISTS municipio text;
