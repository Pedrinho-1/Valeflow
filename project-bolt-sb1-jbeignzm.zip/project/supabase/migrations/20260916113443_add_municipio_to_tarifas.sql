/*
# Adicionar coluna municipio à tabela tarifas

## Changes
- Adiciona coluna `municipio` (text, nullable) à tabela `tarifas`.
- Permite que cada tarifa tenha UF + Município + Concessionária como contexto.
- Atualiza tarifas existentes com município padrão "São Paulo" para SP.

## Security
- Sem mudanças em RLS — a tabela já tem policies para anon, authenticated.
*/

ALTER TABLE tarifas ADD COLUMN IF NOT EXISTS municipio text;

-- Atualiza tarifas existentes
UPDATE tarifas SET municipio = 'São Paulo' WHERE uf = 'SP' AND municipio IS NULL;
