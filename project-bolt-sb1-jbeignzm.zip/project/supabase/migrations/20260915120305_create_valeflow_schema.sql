/*
# ValeFlow - Sistema de Conciliação de Vale-Transporte

## Overview
Reestrutura o banco de dados do TransportControl para o ValeFlow, um sistema
de conciliação de vale-transporte usado por uma operadora. As tabelas antigas
(vehicles, drivers, routes, trips, maintenance_records) são preservadas mas
não usadas pelo novo sistema.

## New Tables

1. competencias
   - id (uuid PK)
   - referencia (text, unique, formato MM/AAAA)
   - status (text: rascunho | em_processamento | em_conferencia | finalizada)
   - ativa (boolean, apenas uma ativa por vez)
   - total_funcionarios (int)
   - total_unidades (int)
   - total_calculado (numeric)
   - total_pago (numeric)
   - total_complementar (numeric)
   - total_divergencias (int)
   - justificativa_reabertura (text, nullable)
   - created_at, updated_at (timestamptz)

2. tarifas
   - id (uuid PK)
   - codigo_linha (text, unique)
   - descricao (text)
   - uf (text)
   - concessionaria (text)
   - valor (numeric, valor da tarifa em reais)
   - ativa (boolean, default true)
   - created_at, updated_at (timestamptz)

3. funcionarios
   - id (uuid PK)
   - competencia_id (uuid FK -> competencias)
   - empresa (text)
   - razao_social (text)
   - uf (text)
   - unidade (text)
   - matricula (text)
   - nome (text)
   - cpf (text)
   - escala (text)
   - banco (text)
   - agencia (text)
   - conta (text)
   - dias_uteis (int)
   - dias_ferias (int)
   - dias_atestato (int)
   - qtd_passagens_diarias (int)
   - codigo_linha (text)
   - valor_tarifa (numeric, tarifa normalizada da planilha)
   - valor_tarifa_referencia (numeric, tarifa da tabela de referência)
   - valor_pago (numeric, valor pago informado)
   - valor_calculado (numeric, calculado pelo motor)
   - valor_complementar (numeric, diferença)
   - status (text: ok | divergencia | complemento | pago_superior)
   - created_at (timestamptz)

4. excecoes
   - id (uuid PK)
   - competencia_id (uuid FK -> competencias)
   - funcionario_id (uuid FK -> funcionarios, nullable)
   - tipo (text: divergencia_valores | tarifa_nao_encontrada | tarifa_divergente | cpf_invalido | cpf_duplicado | dados_ausentes | erro_calculo | erro_importacao)
   - funcionario_nome (text)
   - competencia_ref (text)
   - valor_afetado (numeric)
   - descricao (text)
   - status (text: pendente | resolvida | ignorada)
   - justificativa (text, nullable)
   - data_resolucao (timestamptz, nullable)
   - created_at (timestamptz)

5. competencia_historico
   - id (uuid PK)
   - competencia_id (uuid FK -> competencias)
   - acao (text: criada | status_alterado | reaberta | finalizada | importacao)
   - status_anterior (text, nullable)
   - status_novo (text, nullable)
   - justificativa (text, nullable)
   - detalhe (text, nullable)
   - created_at (timestamptz)

## Security
- RLS habilitado em todas as tabelas.
- App sem login: policies TO anon, authenticated com USING(true) / WITH CHECK(true).
- Dados são intencionalmente compartilhados (single-tenant, operadora única).
*/

-- competencias
CREATE TABLE IF NOT EXISTS competencias (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referencia text UNIQUE NOT NULL,
  status text NOT NULL DEFAULT 'rascunho',
  ativa boolean NOT NULL DEFAULT false,
  total_funcionarios int NOT NULL DEFAULT 0,
  total_unidades int NOT NULL DEFAULT 0,
  total_calculado numeric NOT NULL DEFAULT 0,
  total_pago numeric NOT NULL DEFAULT 0,
  total_complementar numeric NOT NULL DEFAULT 0,
  total_divergencias int NOT NULL DEFAULT 0,
  justificativa_reabertura text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE competencias ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_competencias" ON competencias;
CREATE POLICY "anon_select_competencias" ON competencias FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_competencias" ON competencias;
CREATE POLICY "anon_insert_competencias" ON competencias FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_competencias" ON competencias;
CREATE POLICY "anon_update_competencias" ON competencias FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_competencias" ON competencias;
CREATE POLICY "anon_delete_competencias" ON competencias FOR DELETE
  TO anon, authenticated USING (true);

-- tarifas
CREATE TABLE IF NOT EXISTS tarifas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  codigo_linha text UNIQUE NOT NULL,
  descricao text NOT NULL,
  uf text NOT NULL,
  concessionaria text NOT NULL,
  valor numeric NOT NULL DEFAULT 0,
  ativa boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE tarifas ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_tarifas" ON tarifas;
CREATE POLICY "anon_select_tarifas" ON tarifas FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_tarifas" ON tarifas;
CREATE POLICY "anon_insert_tarifas" ON tarifas FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_tarifas" ON tarifas;
CREATE POLICY "anon_update_tarifas" ON tarifas FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_tarifas" ON tarifas;
CREATE POLICY "anon_delete_tarifas" ON tarifas FOR DELETE
  TO anon, authenticated USING (true);

-- funcionarios
CREATE TABLE IF NOT EXISTS funcionarios (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  competencia_id uuid NOT NULL REFERENCES competencias(id) ON DELETE CASCADE,
  empresa text,
  razao_social text,
  uf text,
  unidade text,
  matricula text,
  nome text,
  cpf text,
  escala text,
  banco text,
  agencia text,
  conta text,
  dias_uteis int NOT NULL DEFAULT 0,
  dias_ferias int NOT NULL DEFAULT 0,
  dias_atestato int NOT NULL DEFAULT 0,
  qtd_passagens_diarias int NOT NULL DEFAULT 0,
  codigo_linha text,
  valor_tarifa numeric NOT NULL DEFAULT 0,
  valor_tarifa_referencia numeric NOT NULL DEFAULT 0,
  valor_pago numeric NOT NULL DEFAULT 0,
  valor_calculado numeric NOT NULL DEFAULT 0,
  valor_complementar numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'ok',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE funcionarios ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_funcionarios" ON funcionarios;
CREATE POLICY "anon_select_funcionarios" ON funcionarios FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_funcionarios" ON funcionarios;
CREATE POLICY "anon_insert_funcionarios" ON funcionarios FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_funcionarios" ON funcionarios;
CREATE POLICY "anon_update_funcionarios" ON funcionarios FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_funcionarios" ON funcionarios;
CREATE POLICY "anon_delete_funcionarios" ON funcionarios FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_funcionarios_competencia ON funcionarios(competencia_id);
CREATE INDEX IF NOT EXISTS idx_funcionarios_cpf ON funcionarios(cpf);

-- excecoes
CREATE TABLE IF NOT EXISTS excecoes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  competencia_id uuid NOT NULL REFERENCES competencias(id) ON DELETE CASCADE,
  funcionario_id uuid REFERENCES funcionarios(id) ON DELETE SET NULL,
  tipo text NOT NULL,
  funcionario_nome text,
  competencia_ref text,
  valor_afetado numeric NOT NULL DEFAULT 0,
  descricao text NOT NULL,
  status text NOT NULL DEFAULT 'pendente',
  justificativa text,
  data_resolucao timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE excecoes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_excecoes" ON excecoes;
CREATE POLICY "anon_select_excecoes" ON excecoes FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_excecoes" ON excecoes;
CREATE POLICY "anon_insert_excecoes" ON excecoes FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_excecoes" ON excecoes;
CREATE POLICY "anon_update_excecoes" ON excecoes FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_excecoes" ON excecoes;
CREATE POLICY "anon_delete_excecoes" ON excecoes FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_excecoes_competencia ON excecoes(competencia_id);
CREATE INDEX IF NOT EXISTS idx_excecoes_status ON excecoes(status);

-- competencia_historico
CREATE TABLE IF NOT EXISTS competencia_historico (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  competencia_id uuid NOT NULL REFERENCES competencias(id) ON DELETE CASCADE,
  acao text NOT NULL,
  status_anterior text,
  status_novo text,
  justificativa text,
  detalhe text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE competencia_historico ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_historico" ON competencia_historico;
CREATE POLICY "anon_select_historico" ON competencia_historico FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_historico" ON competencia_historico;
CREATE POLICY "anon_insert_historico" ON competencia_historico FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_historico" ON competencia_historico;
CREATE POLICY "anon_delete_historico" ON competencia_historico FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_historico_competencia ON competencia_historico(competencia_id);

-- Seed tarifas
INSERT INTO tarifas (codigo_linha, descricao, uf, concessionaria, valor, ativa) VALUES
('001', 'Linha Centro - Circular', 'SP', 'Viação Lemos', 5.90, true),
('002', 'Linha Norte - Expresso', 'SP', 'Viação Lemos', 6.90, true),
('003', 'Linha Sul - Executivo', 'SP', 'Viação Lemos', 7.50, true),
('004', 'Linha Leste - Local', 'SP', 'Auto Viação Passos', 5.50, true),
('005', 'Linha Oeste - Interurbano', 'SP', 'Auto Viação Passos', 12.00, true),
('006', 'Linha Metropolitana A', 'SP', 'Empresa Turismo', 8.20, true),
('007', 'Linha Metropolitana B', 'SP', 'Empresa Turismo', 9.10, true),
('008', 'Linha Regional Norte', 'SP', 'Viação Lemos', 10.50, true),
('009', 'Linha Regional Sul', 'SP', 'Viação Lemos', 11.30, true),
('010', 'Linha Regional Leste', 'SP', 'Auto Viação Passos', 9.80, true)
ON CONFLICT (codigo_linha) DO NOTHING;
