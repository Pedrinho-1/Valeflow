import { cn } from '@/lib/utils';

const styles: Record<string, string> = {
  // Competência
  rascunho: 'bg-slate-100 text-slate-600',
  em_processamento: 'bg-blue-100 text-blue-700',
  em_conferencia: 'bg-amber-100 text-amber-700',
  finalizada: 'bg-emerald-100 text-emerald-700',
  // Exceção
  pendente: 'bg-amber-100 text-amber-700',
  resolvida: 'bg-emerald-100 text-emerald-700',
  ignorada: 'bg-slate-100 text-slate-500',
  // Funcionário
  ok: 'bg-emerald-100 text-emerald-700',
  divergencia: 'bg-red-100 text-red-700',
  complemento: 'bg-amber-100 text-amber-700',
  pago_superior: 'bg-indigo-100 text-indigo-700',
  // Tarifa
  ativa: 'bg-emerald-100 text-emerald-700',
  inativa: 'bg-slate-100 text-slate-500',
};

const labels: Record<string, string> = {
  rascunho: 'Rascunho',
  em_processamento: 'Em Processamento',
  em_conferencia: 'Em Conferência',
  finalizada: 'Finalizada',
  pendente: 'Pendente',
  resolvida: 'Resolvida',
  ignorada: 'Ignorada',
  ok: 'OK',
  divergencia: 'Divergência',
  complemento: 'Complemento',
  pago_superior: 'Pago Superior',
  ativa: 'Ativa',
  inativa: 'Inativa',
};

export function StatusBadge({ status }: { status: string }) {
  const cls = styles[status] ?? 'bg-slate-100 text-slate-600';
  const label = labels[status] ?? status;
  return (
    <span className={cn('inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold', cls)}>
      {label}
    </span>
  );
}

const tipoLabels: Record<string, string> = {
  divergencia_valores: 'Divergência de Valores',
  tarifa_nao_encontrada: 'Tarifa Não Encontrada',
  tarifa_divergente: 'Tarifa Divergente',
  cpf_invalido: 'CPF Inválido',
  cpf_duplicado: 'CPF Duplicado',
  dados_ausentes: 'Dados Ausentes',
  erro_calculo: 'Erro de Cálculo',
  erro_importacao: 'Erro de Importação',
};

export function TipoExcecaoBadge({ tipo }: { tipo: string }) {
  const label = tipoLabels[tipo] ?? tipo;
  return (
    <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-red-50 text-red-600 border border-red-200">
      {label}
    </span>
  );
}
