import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { QueryProvider } from '@/lib/query-provider';
import { Sidebar } from '@/components/Sidebar';
import DashboardPage from '@/pages/DashboardPage';
import CompetenciasPage from '@/pages/CompetenciasPage';
import ImportacaoPage from '@/pages/ImportacaoPage';
import TarifasPage from '@/pages/TarifasPage';
import ExcecoesPage from '@/pages/ExcecoesPage';

export default function App() {
  return (
    <QueryProvider>
      <BrowserRouter>
        <div className="min-h-screen bg-slate-50">
          <Sidebar />
          <main className="lg:ml-64 min-h-screen">
            <div className="p-6 lg:p-8 pt-16 lg:pt-8 max-w-7xl mx-auto">
              <Routes>
                <Route path="/" element={<DashboardPage />} />
                <Route path="/competencias" element={<CompetenciasPage />} />
                <Route path="/importacao" element={<ImportacaoPage />} />
                <Route path="/tarifas" element={<TarifasPage />} />
                <Route path="/excecoes" element={<ExcecoesPage />} />
              </Routes>
            </div>
          </main>
        </div>
      </BrowserRouter>
    </QueryProvider>
  );
}
