import * as XLSX from 'xlsx';
import { normalizeHeader } from './calculation';

export type ParseFileResult = {
  rows: Record<string, unknown>[];
  fileName: string;
};

/**
 * Converts an array-of-arrays matrix (header: 1 mode) into row objects.
 * First row becomes headers (normalized via normalizeHeader), subsequent
 * rows become objects keyed by those normalized headers.
 */
function matrixToObjects(matrix: unknown[][]): Record<string, unknown>[] {
  if (!Array.isArray(matrix) || matrix.length < 2) return [];

  const headerRow = matrix[0];
  if (!Array.isArray(headerRow)) return [];

  const headers: string[] = [];
  for (const h of headerRow) {
    const normalized = normalizeHeader(String(h ?? ''));
    headers.push(normalized);
  }

  const result: Record<string, unknown>[] = [];

  for (let i = 1; i < matrix.length; i++) {
    const arr = matrix[i];
    if (!Array.isArray(arr)) continue;

    const obj: Record<string, unknown> = {};
    let hasValue = false;

    for (let j = 0; j < headers.length; j++) {
      const key = headers[j];
      if (!key) continue;
      const val = arr[j] ?? '';
      obj[key] = val;
      if (val !== '' && val !== null && val !== undefined) {
        hasValue = true;
      }
    }

    if (hasValue && Object.keys(obj).length > 0) {
      result.push(obj);
    }
  }

  return result;
}

/**
 * Reads a worksheet in array-of-arrays mode (header: 1) which avoids
 * the "names is not iterable" error entirely.
 */
function safeSheetToJson(ws: XLSX.WorkSheet): Record<string, unknown>[] {
  if (!ws || !ws['!ref']) return [];

  let matrix: unknown[][];

  try {
    matrix = XLSX.utils.sheet_to_json<unknown[]>(ws, {
      header: 1,
      defval: '',
      blankrows: false,
      raw: true,
    });
  } catch {
    try {
      matrix = XLSX.utils.sheet_to_json<unknown[]>(ws, {
        header: 1,
        defval: '',
        blankrows: false,
        raw: false,
      });
    } catch {
      return [];
    }
  }

  return matrixToObjects(matrix);
}

/**
 * Parses spreadsheet files (XLSX, XLS) using SheetJS.
 */
async function parseSpreadsheet(file: File): Promise<Record<string, unknown>[]> {
  const buf = await file.arrayBuffer();
  let wb: XLSX.WorkBook;
  try {
    wb = XLSX.read(buf, { type: 'array', cellDates: true });
  } catch {
    return [];
  }
  if (!wb.SheetNames || !Array.isArray(wb.SheetNames) || wb.SheetNames.length === 0) {
    return [];
  }
  const ws = wb.Sheets[wb.SheetNames[0]];
  return safeSheetToJson(ws);
}

/**
 * Parses a plain-text delimited file (CSV, TSV, TXT).
 * Detects the delimiter from file extension and content.
 */
async function parseTextDelimited(file: File): Promise<Record<string, unknown>[]> {
  const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
  const buf = await file.arrayBuffer();

  let wb: XLSX.WorkBook;
  try {
    const readOpts: XLSX.ParsingOptions = {
      type: 'array',
      raw: true,
    };
    if (ext === 'tsv') {
      readOpts.FS = '\t';
    }
    wb = XLSX.read(buf, readOpts);
  } catch {
    return [];
  }
  if (!wb.SheetNames || !Array.isArray(wb.SheetNames) || wb.SheetNames.length === 0) {
    return [];
  }
  const ws = wb.Sheets[wb.SheetNames[0]];
  return safeSheetToJson(ws);
}

/**
 * Parses PDF files using pdfjs-dist, extracting text and attempting
 * to detect tabular data. Falls back to line-based parsing.
 */
async function parsePdf(file: File): Promise<Record<string, unknown>[]> {
  const pdfjs = await import('pdfjs-dist');
  const workerUrl = (await import('pdfjs-dist/build/pdf.worker.min.mjs?url')).default;
  pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;

  const buf = await file.arrayBuffer();
  const pdf = await pdfjs.getDocument({ data: buf }).promise;
  const allRows: Record<string, unknown>[] = [];
  let headers: string[] | null = null;

  for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
    const page = await pdf.getPage(pageNum);
    const textContent = await page.getTextContent();

    const rowMap = new Map<number, { x: number; str: string }[]>();
    const tolerance = 3;

    for (const item of textContent.items) {
      if (!('str' in item) || !item.str.trim()) continue;
      const transform = (item as { transform: number[] }).transform;
      const y = Math.round(transform[5] / tolerance) * tolerance;
      const x = transform[4];
      if (!rowMap.has(y)) rowMap.set(y, []);
      rowMap.get(y)!.push({ x, str: item.str.trim() });
    }

    const sortedYs = Array.from(rowMap.keys()).sort((a, b) => b - a);
    const pageRows: string[][] = [];

    for (const y of sortedYs) {
      const items = rowMap.get(y)!.sort((a, b) => a.x - b.x);
      const cells = items.map((i) => i.str).filter((s) => s.length > 0);
      if (cells.length > 0) pageRows.push(cells);
    }

    for (const cells of pageRows) {
      if (!headers) {
        if (cells.length >= 3 && hasLikelyHeaderKeywords(cells)) {
          headers = cells.map(normalizeHeader);
          continue;
        }
        if (cells.length >= 4) {
          headers = cells.map(normalizeHeader);
          continue;
        }
      }
      if (headers && cells.length >= 2) {
        const row: Record<string, unknown> = {};
        for (let i = 0; i < headers.length; i++) {
          row[headers[i]] = cells[i] ?? '';
        }
        allRows.push(row);
      }
    }
  }

  return allRows;
}

function hasLikelyHeaderKeywords(cells: string[]): boolean {
  const joined = cells.join(' ').toLowerCase();
  const keywords = ['nome', 'cpf', 'matricula', 'valor', 'uf', 'linha', 'dias', 'passagens', 'empresa'];
  return keywords.some((k) => joined.includes(k));
}

/**
 * Parses Word documents (.docx, .doc) using mammoth. Extracts HTML tables
 * and converts them to row objects.
 */
async function parseWord(file: File): Promise<Record<string, unknown>[]> {
  let mammoth: typeof import('mammoth/mammoth.browser');
  try {
    mammoth = await import('mammoth/mammoth.browser');
  } catch {
    const fallback = await import('mammoth');
    mammoth = fallback as unknown as typeof import('mammoth/mammoth.browser');
  }

  const arrayBuffer = await file.arrayBuffer();
  const result = await mammoth.convertToHtml({ arrayBuffer });
  const html = result.value;

  const doc = new DOMParser().parseFromString(html, 'text/html');
  const tables = doc.querySelectorAll('table');
  if (tables.length === 0) return [];

  const rows: Record<string, unknown>[] = [];
  const table = tables[0];
  const trs = table.querySelectorAll('tr');
  let headers: string[] | null = null;

  for (const tr of Array.from(trs)) {
    const cells = Array.from(tr.querySelectorAll('td, th')).map((td) => td.textContent?.trim() ?? '');
    if (cells.length === 0) continue;

    if (!headers) {
      headers = cells.map(normalizeHeader);
      continue;
    }
    const row: Record<string, unknown> = {};
    let hasValue = false;
    for (let i = 0; i < headers.length; i++) {
      const val = cells[i] ?? '';
      row[headers[i]] = val;
      if (val) hasValue = true;
    }
    if (hasValue) rows.push(row);
  }

  return rows;
}

/**
 * Detects file type by extension and MIME type, then routes to the
 * appropriate parser. Returns normalized row objects.
 */
export async function parseFile(file: File): Promise<ParseFileResult> {
  const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
  const mime = file.type;

  let rows: Record<string, unknown>[];

  if (ext === 'xlsx' || ext === 'xls' || mime === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || mime === 'application/vnd.ms-excel') {
    rows = await parseSpreadsheet(file);
  } else if (ext === 'csv' || ext === 'tsv' || ext === 'txt' || mime === 'text/csv' || mime === 'text/plain') {
    rows = await parseTextDelimited(file);
  } else if (ext === 'pdf' || mime === 'application/pdf') {
    rows = await parsePdf(file);
  } else if (ext === 'docx' || ext === 'doc' || mime.includes('wordprocessing') || mime.includes('msword')) {
    rows = await parseWord(file);
  } else {
    try {
      rows = await parseSpreadsheet(file);
    } catch {
      throw new Error(`Formato não suportado: .${ext}. Use XLSX, XLS, CSV, TSV, TXT, PDF, DOCX ou DOC.`);
    }
  }

  if (rows.length === 0) {
    throw new Error('Nenhuma linha de dados encontrada no arquivo. Verifique se o arquivo contém uma tabela com cabeçalhos.');
  }

  return { rows, fileName: file.name };
}
