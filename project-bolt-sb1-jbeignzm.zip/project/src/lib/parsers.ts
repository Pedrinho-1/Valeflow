/**
 * Parser centralizado para valores monetários.
 * Aceita: 5,90 | 5.90 | R$ 5,90 | 590 (centavos) | "5.9"
 */
export function parseCurrency(raw: unknown, isCents = false): number {
  if (raw === null || raw === undefined || raw === '') return 0;

  if (typeof raw === 'number') {
    return isCents ? raw / 100 : raw;
  }

  const str = String(raw).trim();
  if (!str) return 0;

  // Remove R$, espaços, e outros caracteres não numéricos excito . e ,
  const cleaned = str.replace(/[R$\s]/g, '');

  // Se tem vírgula e ponto, assume formato BR (1.234,56)
  if (cleaned.includes(',') && cleaned.includes('.')) {
    const normalized = cleaned.replace(/\./g, '').replace(',', '.');
    const val = parseFloat(normalized);
    return isNaN(val) ? 0 : isCents ? val / 100 : val;
  }

  // Se tem apenas vírgula, assume formato BR (5,90)
  if (cleaned.includes(',')) {
    const normalized = cleaned.replace(',', '.');
    const val = parseFloat(normalized);
    return isNaN(val) ? 0 : isCents ? val / 100 : val;
  }

  const val = parseFloat(cleaned);
  if (isNaN(val)) return 0;
  return isCents ? val / 100 : val;
}

export function parseIntSafe(raw: unknown): number {
  if (raw === null || raw === undefined || raw === '') return 0;
  if (typeof raw === 'number') return Math.trunc(raw);
  const str = String(raw).trim().replace(/[^\d-]/g, '');
  const val = parseInt(str, 10);
  return isNaN(val) ? 0 : val;
}

/**
 * Validação de CPF com dígitos verificadores.
 */
export function validateCPF(raw: string): boolean {
  const cpf = String(raw ?? '').replace(/[^\d]/g, '');
  if (cpf.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(cpf)) return false; // todos iguais

  let sum = 0;
  for (let i = 0; i < 9; i++) sum += parseInt(cpf[i]) * (10 - i);
  let dv1 = 11 - (sum % 11);
  if (dv1 >= 10) dv1 = 0;
  if (dv1 !== parseInt(cpf[9])) return false;

  sum = 0;
  for (let i = 0; i < 10; i++) sum += parseInt(cpf[i]) * (11 - i);
  let dv2 = 11 - (sum % 11);
  if (dv2 >= 10) dv2 = 0;
  if (dv2 !== parseInt(cpf[10])) return false;

  return true;
}

export function formatCPF(raw: string): string {
  const digits = String(raw ?? '').replace(/[^\d]/g, '');
  if (digits.length !== 11) return raw ?? '';
  return digits.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
}
