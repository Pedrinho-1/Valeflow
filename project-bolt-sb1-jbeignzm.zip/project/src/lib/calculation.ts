import { parseCurrency, parseIntSafe, validateCPF } from './parsers';
import type { FuncionarioInsert, ExcecaoInsert, Tarifa } from '@/types';

export type ParsedRow = {
  raw: Record<string, unknown>;
  funcionario: FuncionarioInsert;
  excecoes: ExcecaoInsert[];
  tarifaEncontrada: boolean;
  tarifaDivergente: boolean;
};

export type ValidationResult = {
  rows: ParsedRow[];
  totalRegistros: number;
  registrosValidos: number;
  registrosComErro: number;
  totalCalculado: number;
  totalPago: number;
  totalComplementar: number;
  totalExcecoes: number;
};

/**
 * Normaliza nomes de colunas para lower case sem acentos.
 */
export function normalizeHeader(header: string): string {
  return header
    .toLowerCase()
    .trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, '_');
}

/**
 * Busca um valor em uma linha por múltiplos nomes de coluna possíveis.
 * Todos os nomes são normalizados antes da comparação — a normalização
 * remove acentos e espaços extras, então "Matrícula" = "Matricula".
 */
function getField(row: Record<string, unknown>, names: string[]): unknown {
  const normalizedNames = names.map((n) => normalizeHeader(n));
  for (const name of normalizedNames) {
    if (row[name] !== undefined && row[name] !== null && row[name] !== '') {
      return row[name];
    }
  }
  return undefined;
}

const columnAliases: Record<string, string[]> = {
  empresa: ['empresa', 'companhia'],
  razao_social: ['razao social', 'razaosocial', 'razao_social', 'razao social da empresa'],
  uf: ['uf', 'estado'],
  municipio: ['municipio', 'cidade'],
  unidade: ['unidade', 'setor', 'lotacao'],
  matricula: ['matricula', 'matr.', 'id matricula', 'numero matricula'],
  nome: ['nome do funcionario', 'nome', 'nome funcionario', 'funcionario', 'nome do colaborador', 'colaborador'],
  cpf: ['cpf', 'cpf/cnpj'],
  escala: ['escala', 'tipo escala', 'jornada'],
  banco: ['banco', 'instituicao financeira'],
  agencia: ['agencia', 'ag.', 'numero agencia'],
  conta: ['conta', 'numero conta', 'conta corrente'],
  competencia: ['competencia', 'comp.', 'periodo', 'referencia'],
  dias_uteis: ['dias uteis', 'diasuteis', 'du', 'dias trabalhados', 'dias trab'],
  dias_ferias: ['dias de ferias', 'dias ferias', 'diasferias', 'ferias', 'dias de ferias/gozo'],
  dias_atestado: ['dias de atestado/falta', 'dias de atestado', 'dias atestado', 'diasatestado', 'atestado', 'faltas', 'dias de falta', 'dias faltas'],
  qtd_passagens_diarias: ['quantidade de passagens diarias', 'qtd passagens', 'passagens diarias', 'qtd passagens diarias', 'quantidade passagens', 'passagens'],
  codigo_linha: ['codigo/linha', 'codigo linha', 'codigolinha', 'linha', 'cod linha', 'codigo', 'codigo da linha'],
  valor_pago: ['valor pago', 'valorpago', 'vlr pago', 'valor total pago', 'total pago'],
  valor_tarifa: ['valor tarifa', 'valortarifa', 'tarifa', 'vlr tarifa', 'valor da tarifa', 'valor passagem'],
};

function getRowField(row: Record<string, unknown>, key: keyof typeof columnAliases): unknown {
  return getField(row, columnAliases[key]);
}

/**
 * Motor de cálculo centralizado.
 */
export function calculateFuncionario(
  row: Record<string, unknown>,
  competenciaId: string,
  competenciaRef: string,
  tarifas: Tarifa[],
  isCents: boolean
): ParsedRow {
  const excecoes: ExcecaoInsert[] = [];

  const nome = String(getRowField(row, 'nome') ?? '').trim();
  const cpf = String(getRowField(row, 'cpf') ?? '').trim();
  const codigoLinha = String(getRowField(row, 'codigo_linha') ?? '').trim();
  const uf = String(getRowField(row, 'uf') ?? '').trim().toUpperCase();
  const municipio = String(getRowField(row, 'municipio') ?? '').trim();
  const unidade = String(getRowField(row, 'unidade') ?? '').trim();

  const diasUteis = parseIntSafe(getRowField(row, 'dias_uteis'));
  const diasFerias = parseIntSafe(getRowField(row, 'dias_ferias'));
  const diasAtestado = parseIntSafe(getRowField(row, 'dias_atestado'));
  const qtdPassagens = parseIntSafe(getRowField(row, 'qtd_passagens_diarias'));
  const valorPago = parseCurrency(getRowField(row, 'valor_pago'), isCents);
  const valorTarifaPlanilha = parseCurrency(getRowField(row, 'valor_tarifa'), isCents);

  // Validações
  if (!nome) {
    excecoes.push({
      competencia_id: competenciaId,
      funcionario_id: null,
      tipo: 'dados_ausentes',
      funcionario_nome: '—',
      competencia_ref: competenciaRef,
      valor_afetado: 0,
      descricao: 'Nome do funcionário ausente.',
      status: 'pendente',
      justificativa: null,
      data_resolucao: null,
    });
  }

  if (cpf && !validateCPF(cpf)) {
    excecoes.push({
      competencia_id: competenciaId,
      funcionario_id: null,
      tipo: 'cpf_invalido',
      funcionario_nome: nome || '—',
      competencia_ref: competenciaRef,
      valor_afetado: 0,
      descricao: `CPF inválido: ${cpf}`,
      status: 'pendente',
      justificativa: null,
      data_resolucao: null,
    });
  }

  // Busca tarifa na tabela de referência por código/linha
  let tarifaReferencia: Tarifa | undefined;
  let tarifaEncontrada = false;
  let tarifaDivergente = false;

  if (codigoLinha) {
    tarifaReferencia = tarifas.find(
      (t) => t.codigo_linha === codigoLinha && t.ativa
    );
    // Se não encontrou por código, tenta por UF + Município + Concessionária
    if (!tarifaReferencia && uf && municipio) {
      tarifaReferencia = tarifas.find(
        (t) => t.ativa && t.uf === uf && (t.municipio ?? '').toLowerCase() === municipio.toLowerCase()
      );
    }
    if (tarifaReferencia) {
      tarifaEncontrada = true;
      if (valorTarifaPlanilha > 0 && Math.abs(valorTarifaPlanilha - tarifaReferencia.valor) > 0.001) {
        tarifaDivergente = true;
        excecoes.push({
          competencia_id: competenciaId,
          funcionario_id: null,
          tipo: 'tarifa_divergente',
          funcionario_nome: nome || '—',
          competencia_ref: competenciaRef,
          valor_afetado: Math.abs(valorTarifaPlanilha - tarifaReferencia.valor),
          descricao: `Tarifa divergente: planilha R$ ${valorTarifaPlanilha.toFixed(2)} vs referência R$ ${tarifaReferencia.valor.toFixed(2)} (linha ${codigoLinha}).`,
          status: 'pendente',
          justificativa: null,
          data_resolucao: null,
        });
      }
    } else {
      excecoes.push({
        competencia_id: competenciaId,
        funcionario_id: null,
        tipo: 'tarifa_nao_encontrada',
        funcionario_nome: nome || '—',
        competencia_ref: competenciaRef,
        valor_afetado: valorTarifaPlanilha,
        descricao: `Tarifa não encontrada para linha ${codigoLinha} - UF ${uf}${municipio ? ' / ' + municipio : ''}.`,
        status: 'pendente',
        justificativa: null,
        data_resolucao: null,
      });
    }
  } else if (!tarifaReferencia && valorTarifaPlanilha === 0) {
    excecoes.push({
      competencia_id: competenciaId,
      funcionario_id: null,
      tipo: 'dados_ausentes',
      funcionario_nome: nome || '—',
      competencia_ref: competenciaRef,
      valor_afetado: 0,
      descricao: 'Código/Linha e valor de tarifa ausentes. Não é possível calcular.',
      status: 'pendente',
      justificativa: null,
      data_resolucao: null,
    });
  }

  // Cálculo
  const tarifaCorrigida = tarifaReferencia?.valor ?? valorTarifaPlanilha;
  const diasAtivos = Math.max(0, diasUteis - (diasFerias + diasAtestado));
  const valorCalculado = diasAtivos * qtdPassagens * tarifaCorrigida;
  const valorComplementar = valorCalculado - valorPago;

  let status: FuncionarioInsert['status'] = 'ok';
  if (valorComplementar > 0.001) {
    status = 'complemento';
  } else if (valorComplementar < -0.001) {
    status = 'pago_superior';
  }

  if (status !== 'ok' && Math.abs(valorComplementar) > 0.001) {
    excecoes.push({
      competencia_id: competenciaId,
      funcionario_id: null,
      tipo: 'divergencia_valores',
      funcionario_nome: nome || '—',
      competencia_ref: competenciaRef,
      valor_afetado: Math.abs(valorComplementar),
      descricao:
        status === 'complemento'
          ? `Valor calculado R$ ${valorCalculado.toFixed(2)} superior ao pago R$ ${valorPago.toFixed(2)}. Complemento: R$ ${Math.abs(valorComplementar).toFixed(2)}.`
          : `Valor pago R$ ${valorPago.toFixed(2)} superior ao calculado R$ ${valorCalculado.toFixed(2)}. Diferença: R$ ${Math.abs(valorComplementar).toFixed(2)}.`,
      status: 'pendente',
      justificativa: null,
      data_resolucao: null,
    });
  }

  const funcionario: FuncionarioInsert = {
    competencia_id: competenciaId,
    empresa: String(getRowField(row, 'empresa') ?? '').trim() || null,
    razao_social: String(getRowField(row, 'razao_social') ?? '').trim() || null,
    uf: uf || null,
    municipio: municipio || null,
    unidade: unidade || null,
    matricula: String(getRowField(row, 'matricula') ?? '').trim() || null,
    nome: nome || null,
    cpf: cpf || null,
    escala: String(getRowField(row, 'escala') ?? '').trim() || null,
    banco: String(getRowField(row, 'banco') ?? '').trim() || null,
    agencia: String(getRowField(row, 'agencia') ?? '').trim() || null,
    conta: String(getRowField(row, 'conta') ?? '').trim() || null,
    dias_uteis: diasUteis,
    dias_ferias: diasFerias,
    dias_atestato: diasAtestado,
    qtd_passagens_diarias: qtdPassagens,
    codigo_linha: codigoLinha || null,
    valor_tarifa: valorTarifaPlanilha,
    valor_tarifa_referencia: tarifaReferencia?.valor ?? 0,
    valor_pago: valorPago,
    valor_calculado: valorCalculado,
    valor_complementar: valorComplementar,
    status: status,
  };

  return {
    raw: row,
    funcionario,
    excecoes,
    tarifaEncontrada,
    tarifaDivergente,
  };
}

/**
 * Processa todas as linhas de uma planilha.
 */
export function validateAndCalculate(
  rows: Record<string, unknown>[],
  competenciaId: string,
  competenciaRef: string,
  tarifas: Tarifa[],
  isCents: boolean
): ValidationResult {
  const parsedRows: ParsedRow[] = [];
  const cpfSet = new Map<string, number>();

  for (const row of rows) {
    const parsed = calculateFuncionario(row, competenciaId, competenciaRef, tarifas, isCents);
    parsedRows.push(parsed);

    const cpf = parsed.funcionario.cpf;
    if (cpf) {
      const count = cpfSet.get(cpf) ?? 0;
      cpfSet.set(cpf, count + 1);
      if (count === 1) {
        parsed.excecoes.push({
          competencia_id: competenciaId,
          funcionario_id: null,
          tipo: 'cpf_duplicado',
          funcionario_nome: parsed.funcionario.nome ?? '—',
          competencia_ref: competenciaRef,
          valor_afetado: parsed.funcionario.valor_calculado,
          descricao: `CPF duplicado na importação: ${cpf}.`,
          status: 'pendente',
          justificativa: null,
          data_resolucao: null,
        });
      }
    }
  }

  const registrosValidos = parsedRows.filter(
    (r) => r.excecoes.length === 0
  ).length;
  const registrosComErro = parsedRows.length - registrosValidos;

  const totalCalculado = parsedRows.reduce(
    (sum, r) => sum + r.funcionario.valor_calculado, 0
  );
  const totalPago = parsedRows.reduce(
    (sum, r) => sum + r.funcionario.valor_pago, 0
  );
  const totalComplementar = parsedRows.reduce(
    (sum, r) => sum + r.funcionario.valor_complementar, 0
  );
  const totalExcecoes = parsedRows.reduce(
    (sum, r) => sum + r.excecoes.length, 0
  );

  return {
    rows: parsedRows,
    totalRegistros: parsedRows.length,
    registrosValidos,
    registrosComErro,
    totalCalculado,
    totalPago,
    totalComplementar,
    totalExcecoes,
  };
}
