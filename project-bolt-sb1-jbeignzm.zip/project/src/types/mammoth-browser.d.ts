declare module 'mammoth/mammoth.browser' {
  export interface ConvertResult {
    value: string;
    messages: { type: string; message: string }[];
  }
  export interface ConvertOptions {
    arrayBuffer?: ArrayBuffer;
  }
  export function convertToHtml(options: ConvertOptions): Promise<ConvertResult>;
  export function extractRawText(options: ConvertOptions): Promise<ConvertResult>;
}
