export type CompetenciaStatus = 'rascunho' | 'em_processamento' | 'em_conferencia' | 'finalizada';

export type Competencia = {
  id: string;
  referencia: string;
  status: CompetenciaStatus;
  ativa: boolean;
  total_funcionarios: number;
  total_unidades: number;
  total_calculado: number;
  total_pago: number;
  total_complementar: number;
  total_divergencias: number;
  justificativa_reabertura: string | null;
  created_at: string;
  updated_at: string;
};

export type Tarifa = {
  id: string;
  regra_nome: string;
  uf: string;
  municipio: string | null;
  valor: number;
  trechos_diarios: number;
  valor_diario_override: number | null;
  ativa: boolean;
  codigo_linha: string | null;
  descricao: string | null;
  concessionaria: string | null;
  created_at: string;
  updated_at: string;
};

export type FuncionarioStatus = 'ok' | 'divergencia' | 'complemento' | 'pago_superior';

export type Funcionario = {
  id: string;
  competencia_id: string;
  empresa: string | null;
  razao_social: string | null;
  uf: string | null;
  municipio: string | null;
  unidade: string | null;
  matricula: string | null;
  nome: string | null;
  cpf: string | null;
  escala: string | null;
  banco: string | null;
  agencia: string | null;
  conta: string | null;
  dias_uteis: number;
  dias_ferias: number;
  dias_atestato: number;
  qtd_passagens_diarias: number;
  codigo_linha: string | null;
  valor_tarifa: number;
  valor_tarifa_referencia: number;
  valor_pago: number;
  valor_calculado: number;
  valor_complementar: number;
  status: FuncionarioStatus;
  created_at: string;
};

export type ExcecaoTipo =
  | 'divergencia_valores'
  | 'tarifa_nao_encontrada'
  | 'tarifa_divergente'
  | 'cpf_invalido'
  | 'cpf_duplicado'
  | 'dados_ausentes'
  | 'erro_calculo'
  | 'erro_importacao';

export type ExcecaoStatus = 'pendente' | 'resolvida' | 'ignorada';

export type Excecao = {
  id: string;
  competencia_id: string;
  funcionario_id: string | null;
  tipo: ExcecaoTipo;
  funcionario_nome: string | null;
  competencia_ref: string | null;
  valor_afetado: number;
  descricao: string;
  status: ExcecaoStatus;
  justificativa: string | null;
  data_resolucao: string | null;
  created_at: string;
};

export type CompetenciaHistorico = {
  id: string;
  competencia_id: string;
  acao: string;
  status_anterior: string | null;
  status_novo: string | null;
  justificativa: string | null;
  detalhe: string | null;
  created_at: string;
};

export type CompetenciaInsert = Omit<Competencia, 'id' | 'created_at' | 'updated_at'>;
export type TarifaInsert = Omit<Tarifa, 'id' | 'created_at' | 'updated_at'>;
export type FuncionarioInsert = Omit<Funcionario, 'id' | 'created_at'>;
export type ExcecaoInsert = Omit<Excecao, 'id' | 'created_at'>;
