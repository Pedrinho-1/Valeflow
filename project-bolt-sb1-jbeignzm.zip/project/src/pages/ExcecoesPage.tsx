import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  AlertTriangle,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { formatCurrency, formatDateTime } from '@/lib/utils';
import { StatusBadge, TipoExcecaoBadge } from '@/components/StatusBadge';
import { Modal } from '@/components/Modal';
import { Button } from '@/components/Button';
import { Select, Textarea } from '@/components/FormFields';
import type { Excecao, ExcecaoStatus, Competencia } from '@/types';

export default function ExcecoesPage() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [compFilter, setCompFilter] = useState('all');
  const [resolveModal, setResolveModal] = useState<Excecao | null>(null);
  const [justificativa, setJustificativa] = useState('');
  const [newStatus, setNewStatus] = useState<ExcecaoStatus>('resolvida');

  const { data: competencias = [] } = useQuery({
    queryKey: ['competencias'],
    queryFn: async () => {
      const { data } = await supabase.from('competencias').select('*').order('created_at', { ascending: false });
      return (data ?? []) as Competencia[];
    },
  });

  const { data: excecoes = [], isLoading } = useQuery({
    queryKey: ['excecoes', compFilter],
    queryFn: async () => {
      let q = supabase.from('excecoes').select('*').order('created_at', { ascending: false });
      if (compFilter !== 'all') q = q.eq('competencia_id', compFilter);
      const { data } = await q;
      return (data ?? []) as Excecao[];
    },
  });

  const resolveMutation = useMutation({
    mutationFn: async () => {
      if (!resolveModal) return;
      await supabase
        .from('excecoes')
        .update({
          status: newStatus,
          justificativa: justificativa,
          data_resolucao: new Date().toISOString(),
        })
        .eq('id', resolveModal.id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['excecoes'] });
      queryClient.invalidateQueries({ queryKey: ['excecoes-pendentes-dashboard'] });
      setResolveModal(null);
      setJustificativa('');
    },
  });

  const filtered = excecoes.filter((e) => {
    const q = search.toLowerCase();
    const matchesSearch =
      (e.funcionario_nome ?? '').toLowerCase().includes(q) ||
      (e.descricao ?? '').toLowerCase().includes(q);
    const matchesStatus = statusFilter === 'all' || e.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const pendentes = filtered.filter((e) => e.status === 'pendente').length;
  const resolvidas = filtered.filter((e) => e.status === 'resolvida').length;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-10 w-10 border-4 border-slate-200 border-t-blue-600" />
      </div>
    );
  }

  const compName = (id: string) => competencias.find((c) => c.id === id)?.referencia ?? '—';

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Gestão de Exceções</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          {filtered.length} exceção(ões) — {pendentes} pendente(s), {resolvidas} resolvida(s)
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar por funcionário ou descrição..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-400"
          />
        </div>
        <Select value={compFilter} onChange={(e) => setCompFilter(e.target.value)}>
          <option value="all">Todas as Competências</option>
          {competencias.map((c) => (
            <option key={c.id} value={c.id}>{c.referencia}</option>
          ))}
        </Select>
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="all">Todos os Status</option>
          <option value="pendente">Pendentes</option>
          <option value="resolvida">Resolvidas</option>
          <option value="ignorada">Ignoradas</option>
        </Select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        {filtered.length === 0 ? (
          <div className="px-6 py-16 text-center text-slate-400">
            <AlertTriangle size={40} className="mx-auto mb-3 text-slate-300" />
            <p>Nenhuma exceção encontrada.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50">
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Tipo</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Funcionário</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Competência</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Valor Afetado</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Descrição</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Status</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Resolução</th>
                  <th className="text-right px-6 py-3 font-semibold text-slate-600">Ação</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((e) => (
                  <tr key={e.id} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="px-6 py-3"><TipoExcecaoBadge tipo={e.tipo} /></td>
                    <td className="px-6 py-3 text-slate-700 font-medium">{e.funcionario_nome ?? '—'}</td>
                    <td className="px-6 py-3 text-slate-600">{e.competencia_ref ?? compName(e.competencia_id)}</td>
                    <td className="px-6 py-3 text-slate-600 font-semibold">
                      {e.valor_afetado > 0 ? formatCurrency(e.valor_afetado) : '—'}
                    </td>
                    <td className="px-6 py-3 text-slate-600 max-w-xs">
                      <p className="truncate" title={e.descricao}>{e.descricao}</p>
                    </td>
                    <td className="px-6 py-3"><StatusBadge status={e.status} /></td>
                    <td className="px-6 py-3 text-xs text-slate-500">
                      {e.data_resolucao ? (
                        <span className="flex items-center gap-1">
                          <CheckCircle2 size={14} className="text-emerald-500" />
                          {formatDateTime(e.data_resolucao)}
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-slate-400">
                          <Clock size={14} /> —
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-3 text-right">
                      {e.status === 'pendente' && (
                        <button
                          onClick={() => {
                            setResolveModal(e);
                            setJustificativa('');
                            setNewStatus('resolvida');
                          }}
                          className="text-xs font-medium text-blue-600 hover:bg-blue-50 px-3 py-1.5 rounded-lg transition-colors"
                        >
                          Resolver
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Resolve Modal */}
      <Modal
        open={!!resolveModal}
        onClose={() => setResolveModal(null)}
        title="Resolver Exceção"
      >
        {resolveModal && (
          <div className="space-y-4">
            <div className="bg-slate-50 rounded-lg p-4 space-y-2">
              <div className="flex items-center gap-2">
                <TipoExcecaoBadge tipo={resolveModal.tipo} />
                <span className="text-sm font-medium text-slate-700">{resolveModal.funcionario_nome ?? '—'}</span>
              </div>
              <p className="text-sm text-slate-600">{resolveModal.descricao}</p>
              {resolveModal.valor_afetado > 0 && (
                <p className="text-sm font-semibold text-slate-700">
                  Valor afetado: {formatCurrency(resolveModal.valor_afetado)}
                </p>
              )}
            </div>

            <label className="block">
              <span className="text-sm font-medium text-slate-700 mb-1.5 block">Status</span>
              <Select value={newStatus} onChange={(e) => setNewStatus(e.target.value as ExcecaoStatus)}>
                <option value="resolvida">Resolvida</option>
                <option value="ignorada">Ignorada</option>
              </Select>
            </label>

            <label className="block">
              <span className="text-sm font-medium text-slate-700 mb-1.5 block">
                Justificativa * <span className="text-slate-400 font-normal">(obrigatória para alterações manuais)</span>
              </span>
              <Textarea
                value={justificativa}
                onChange={(e) => setJustificativa(e.target.value)}
                rows={4}
                placeholder="Descreva a ação tomada para resolver esta exceção..."
              />
            </label>

            <div className="flex justify-end gap-3 pt-2">
              <Button variant="secondary" onClick={() => setResolveModal(null)}>Cancelar</Button>
              <Button
                disabled={!justificativa.trim() || resolveMutation.isPending}
                onClick={() => resolveMutation.mutate()}
              >
                {resolveMutation.isPending ? 'Salvando...' : 'Confirmar Resolução'}
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
