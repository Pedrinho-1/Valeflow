import { useState, useRef } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Upload,
  FileSpreadsheet,
  FileText,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ArrowRight,
  Loader2,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { formatCurrency } from '@/lib/utils';
import { validateAndCalculate, type ValidationResult } from '@/lib/calculation';
import { parseFile } from '@/lib/file-parser';
import { StatusBadge, TipoExcecaoBadge } from '@/components/StatusBadge';
import { Button } from '@/components/Button';
import { Select } from '@/components/FormFields';
import type { Competencia, Tarifa } from '@/types';

type Step = 'idle' | 'parsing' | 'preview' | 'saving' | 'done';

const ACCEPTED_FORMATS = '.xlsx,.xls,.csv,.tsv,.txt,.pdf,.docx,.doc';
const FORMAT_LABELS = 'XLSX, XLS, CSV, TSV, TXT, PDF, DOCX, DOC';

const REQUIRED_IMPORT_COLUMNS = [
  'Nome',
  'CPF',
  'Matrícula',
  'Unidade',
  'Escala',
  'Banco',
  'Agência',
  'Conta',
  'Competência',
  'Dias Úteis',
  'Dias de Férias',
  'Dias de Atestado/Falta',
  'Qtd Passagens Diárias',
  'Valor Pago',
];

export default function ImportacaoPage() {
  const queryClient = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [step, setStep] = useState<Step>('idle');
  const [isCents, setIsCents] = useState(false);
  const [result, setResult] = useState<ValidationResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [importedFileName, setImportedFileName] = useState<string>('');

  const { data: competencias = [] } = useQuery({
    queryKey: ['competencias'],
    queryFn: async () => {
      const { data } = await supabase
        .from('competencias')
        .select('*')
        .neq('status', 'finalizada')
        .order('created_at', { ascending: false });
      return (data ?? []) as Competencia[];
    },
  });

  const { data: tarifas = [] } = useQuery({
    queryKey: ['tarifas'],
    queryFn: async () => {
      const { data } = await supabase.from('tarifas').select('*').eq('ativa', true);
      return (data ?? []) as Tarifa[];
    },
  });

  const [selectedCompId, setSelectedCompId] = useState<string>('');

  const selectedComp = competencias.find((c) => c.id === selectedCompId);
  const isFinalizada = selectedComp?.status === 'finalizada';

  const handleFile = async (file: File) => {
    if (!selectedCompId) {
      setError('Selecione uma competência antes de importar.');
      return;
    }
    if (isFinalizada) {
      setError('A competência selecionada está finalizada. Reabra antes de importar.');
      return;
    }

    setError(null);
    setStep('parsing');
    setImportedFileName(file.name);

    try {
      const { rows: normalizedRows } = await parseFile(file);

      const validation = validateAndCalculate(
        normalizedRows,
        selectedCompId,
        selectedComp?.referencia ?? '',
        tarifas,
        isCents
      );

      setResult(validation);
      setStep('preview');
    } catch (err) {
      setError(
        err instanceof Error
          ? `Erro ao processar arquivo: ${err.message}`
          : 'Erro ao ler o arquivo. Verifique o formato e se contém uma tabela com cabeçalhos.'
      );
      setStep('idle');
    }
  };

  const handleConfirm = async () => {
    if (!result || !selectedComp) return;
    setStep('saving');

    try {
      const funcionariosData = result.rows.map((r) => r.funcionario);
      const excecoesData = result.rows.flatMap((r) => r.excecoes);

      await supabase.from('funcionarios').delete().eq('competencia_id', selectedComp.id);
      await supabase.from('excecoes').delete().eq('competencia_id', selectedComp.id);

      const { data: insertedFuncs, error: funcError } = await supabase
        .from('funcionarios')
        .insert(funcionariosData)
        .select('id, nome, cpf');

      if (funcError) throw new Error(`Erro ao gravar funcionários: ${funcError.message}`);

      const excecoesWithIds = excecoesData.map((exc) => {
        const func = insertedFuncs?.find(
          (f: { id: string; nome: string | null; cpf: string | null }) =>
            f.nome === exc.funcionario_nome && f.cpf !== null
        );
        return { ...exc, funcionario_id: func?.id ?? null };
      });

      if (excecoesWithIds.length > 0) {
        await supabase.from('excecoes').insert(excecoesWithIds);
      }

      const unidades = new Set(funcionariosData.map((f) => f.unidade).filter(Boolean));
      const cpfsDivergentes = result.rows.filter((r) => r.funcionario.status !== 'ok').length;

      await supabase
        .from('competencias')
        .update({
          total_funcionarios: result.totalRegistros,
          total_unidades: unidades.size,
          total_calculado: result.totalCalculado,
          total_pago: result.totalPago,
          total_complementar: result.totalComplementar,
          total_divergencias: cpfsDivergentes,
          status: 'em_processamento',
          updated_at: new Date().toISOString(),
        })
        .eq('id', selectedComp.id);

      await supabase.from('competencia_historico').insert({
        competencia_id: selectedComp.id,
        acao: 'importacao',
        detalhe: `${result.totalRegistros} registros importados de ${importedFileName}. ${result.totalExcecoes} exceções geradas.`,
      });

      queryClient.invalidateQueries({ queryKey: ['competencias'] });
      queryClient.invalidateQueries({ queryKey: ['competencia-ativa'] });
      queryClient.invalidateQueries({ queryKey: ['excecoes'] });

      setStep('done');
    } catch (err) {
      setError(`Erro na gravação: ${err instanceof Error ? err.message : 'Erro desconhecido'}`);
      setStep('preview');
    }
  };

  const handleReset = () => {
    setStep('idle');
    setResult(null);
    setError(null);
    setImportedFileName('');
    if (fileRef.current) fileRef.current.value = '';
  };

  const formatIcon = (fileName: string) => {
    const ext = fileName.split('.').pop()?.toLowerCase() ?? '';
    if (ext === 'pdf') return FileText;
    if (ext === 'docx' || ext === 'doc') return FileText;
    return FileSpreadsheet;
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Importação de Dados</h1>
        <p className="text-sm text-slate-500 mt-0.5">Upload de planilhas e documentos para conciliação</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200">
          <h2 className="text-base font-bold text-slate-900">Formato esperado</h2>
        </div>
        <div className="px-5 py-4">
          <p className="text-sm text-slate-600 leading-relaxed">
            O documento precisa ter uma linha de cabeçalho com as colunas abaixo. O sistema calcula automaticamente Dias Ativos, VT Calculado e Valor Complementar.
          </p>
          <div className="flex flex-wrap gap-2 mt-3">
            {REQUIRED_IMPORT_COLUMNS.map((column) => (
              <span key={column} className="px-2.5 py-1 rounded-md bg-slate-100 border border-slate-200 text-xs font-medium text-slate-700">
                {column}
              </span>
            ))}
          </div>
          <p className="text-xs text-slate-500 mt-3">
            Também são aceitos UF, Município, Empresa, Razão Social, Código/Linha, Valor Tarifa e outros campos adicionais. Os nomes podem estar com ou sem acentos.
          </p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
        <label className="block">
          <span className="text-sm font-medium text-slate-700 mb-1.5 block">Competência</span>
          <Select value={selectedCompId} onChange={(e) => setSelectedCompId(e.target.value)}>
            <option value="">Selecione uma competência...</option>
            {competencias.map((c) => (
              <option key={c.id} value={c.id}>
                {c.referencia} — {c.status === 'rascunho' ? 'Rascunho' : c.status === 'em_processamento' ? 'Em Processamento' : c.status === 'em_conferencia' ? 'Em Conferência' : 'Finalizada'}
              </option>
            ))}
          </Select>
          {competencias.length === 0 && (
            <p className="text-xs text-amber-600 mt-2">Não há competências disponíveis para importação. Crie uma competência e avance o status antes de importar.</p>
          )}
        </label>
        {isFinalizada && (
          <p className="text-xs text-amber-600 mt-2 flex items-center gap-1">
            <AlertTriangle size={14} /> Competência finalizada — reabra antes de importar.
          </p>
        )}
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-3">
          <XCircle size={20} className="text-red-600 flex-shrink-0" />
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}

      {step === 'idle' && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8">
          <div
            className="border-2 border-dashed border-slate-300 rounded-xl p-12 text-center hover:border-blue-400 transition-colors cursor-pointer"
            onClick={() => fileRef.current?.click()}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
            }}
          >
            <Upload size={48} className="mx-auto mb-4 text-slate-300" />
            <p className="text-sm font-medium text-slate-600">Clique ou arraste um arquivo</p>
            <p className="text-xs text-slate-400 mt-1">Formatos: {FORMAT_LABELS}</p>
            <input
              ref={fileRef}
              type="file"
              accept={ACCEPTED_FORMATS}
              className="hidden"
              onChange={(e) => {
                if (e.target.files?.[0]) handleFile(e.target.files[0]);
              }}
            />
          </div>

          <div className="mt-4 flex items-center gap-3">
            <label className="flex items-center gap-2 text-sm text-slate-600">
              <input
                type="checkbox"
                checked={isCents}
                onChange={(e) => setIsCents(e.target.checked)}
                className="rounded border-slate-300"
              />
              Valores monetários em centavos (ex: 590 = R$ 5,90)
            </label>
          </div>

          <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
            <FormatChip icon={FileSpreadsheet} label="Excel" formats="XLSX, XLS" />
            <FormatChip icon={FileSpreadsheet} label="CSV/TXT" formats="CSV, TSV" />
            <FormatChip icon={FileText} label="PDF" formats="PDF" />
            <FormatChip icon={FileText} label="Word" formats="DOCX, DOC" />
          </div>
        </div>
      )}

      {step === 'parsing' && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center">
          <Loader2 size={40} className="mx-auto mb-4 text-blue-600 animate-spin" />
          <p className="text-sm text-slate-600">Processando arquivo: {importedFileName}...</p>
        </div>
      )}

      {step === 'preview' && result && (
        <div className="space-y-5">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-center gap-2 text-sm text-blue-700">
            {(() => {
              const Icon = formatIcon(importedFileName);
              return <Icon size={18} className="flex-shrink-0" />;
            })()}
            <span>Arquivo processado: <strong>{importedFileName}</strong></span>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <SummaryCard label="Total de Registros" value={String(result.totalRegistros)} icon={FileSpreadsheet} color="bg-blue-600" />
            <SummaryCard label="Registros Válidos" value={String(result.registrosValidos)} icon={CheckCircle2} color="bg-emerald-600" />
            <SummaryCard label="Registros com Erro" value={String(result.registrosComErro)} icon={XCircle} color="bg-red-600" />
            <SummaryCard label="Exceções Geradas" value={String(result.totalExcecoes)} icon={AlertTriangle} color="bg-amber-600" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
              <p className="text-sm text-slate-500">Total Calculado</p>
              <p className="text-2xl font-bold text-teal-600 mt-1">{formatCurrency(result.totalCalculado)}</p>
            </div>
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
              <p className="text-sm text-slate-500">Total Pago</p>
              <p className="text-2xl font-bold text-indigo-600 mt-1">{formatCurrency(result.totalPago)}</p>
            </div>
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
              <p className="text-sm text-slate-500">Total Complementar</p>
              <p className="text-2xl font-bold text-amber-600 mt-1">{formatCurrency(result.totalComplementar)}</p>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200">
              <h2 className="text-lg font-bold text-slate-900">Pré-visualização</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <th className="text-left px-4 py-3 font-semibold text-slate-600">Nome</th>
                    <th className="text-left px-4 py-3 font-semibold text-slate-600">Linha</th>
                    <th className="text-left px-4 py-3 font-semibold text-slate-600">Tarifa</th>
                    <th className="text-left px-4 py-3 font-semibold text-slate-600">Calculado</th>
                    <th className="text-left px-4 py-3 font-semibold text-slate-600">Pago</th>
                    <th className="text-left px-4 py-3 font-semibold text-slate-600">Complementar</th>
                    <th className="text-left px-4 py-3 font-semibold text-slate-600">Status</th>
                    <th className="text-left px-4 py-3 font-semibold text-slate-600">Exceções</th>
                  </tr>
                </thead>
                <tbody>
                  {result.rows.slice(0, 50).map((r, i) => (
                    <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="px-4 py-2.5 text-slate-700">{r.funcionario.nome ?? '—'}</td>
                      <td className="px-4 py-2.5 text-slate-600 font-mono text-xs">{r.funcionario.codigo_linha ?? '—'}</td>
                      <td className="px-4 py-2.5 text-slate-600">
                        {formatCurrency(r.funcionario.valor_tarifa_referencia || r.funcionario.valor_tarifa)}
                      </td>
                      <td className="px-4 py-2.5 text-slate-600">{formatCurrency(r.funcionario.valor_calculado)}</td>
                      <td className="px-4 py-2.5 text-slate-600">{formatCurrency(r.funcionario.valor_pago)}</td>
                      <td className="px-4 py-2.5 font-semibold text-amber-600">{formatCurrency(r.funcionario.valor_complementar)}</td>
                      <td className="px-4 py-2.5"><StatusBadge status={r.funcionario.status} /></td>
                      <td className="px-4 py-2.5">
                        <div className="flex flex-wrap gap-1">
                          {r.excecoes.map((exc, j) => (
                            <TipoExcecaoBadge key={j} tipo={exc.tipo} />
                          ))}
                          {r.excecoes.length === 0 && <span className="text-slate-300">—</span>}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {result.rows.length > 50 && (
                <p className="px-6 py-3 text-xs text-slate-400 bg-slate-50">
                  Exibindo os primeiros 50 registros de {result.rows.length}.
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between gap-4">
            <Button variant="secondary" onClick={handleReset}>Cancelar e Reimportar</Button>
            <div className="flex items-center gap-3">
              {result.registrosComErro > 0 && (
                <p className="text-sm text-amber-600 flex items-center gap-1">
                  <AlertTriangle size={16} />
                  {result.registrosComErro} registro(s) com erro serão importados com exceções.
                </p>
              )}
              <Button onClick={handleConfirm}>
                <>Confirmar e Gravar <ArrowRight size={16} /></>
              </Button>
            </div>
          </div>
        </div>
      )}

      {step === 'done' && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center">
          <CheckCircle2 size={48} className="mx-auto mb-4 text-emerald-600" />
          <h3 className="text-lg font-bold text-slate-900">Importação Concluída</h3>
          <p className="text-sm text-slate-500 mt-1">
            {result?.totalRegistros} registros gravados com sucesso de {importedFileName}.
          </p>
          <div className="mt-6 flex justify-center gap-3">
            <Button variant="secondary" onClick={handleReset}>Nova Importação</Button>
          </div>
        </div>
      )}
    </div>
  );
}

function FormatChip({ icon: Icon, label, formats }: { icon: typeof Upload; label: string; formats: string }) {
  return (
    <div className="flex items-center gap-2.5 bg-slate-50 rounded-lg px-3 py-2.5 border border-slate-200">
      <div className="w-8 h-8 rounded-md bg-slate-200 flex items-center justify-center flex-shrink-0">
        <Icon size={16} className="text-slate-600" />
      </div>
      <div>
        <p className="text-xs font-semibold text-slate-700">{label}</p>
        <p className="text-[10px] text-slate-400">{formats}</p>
      </div>
    </div>
  );
}

function SummaryCard({ label, value, icon: Icon, color }: { label: string; value: string; icon: typeof Upload; color: string }) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-lg ${color} flex items-center justify-center flex-shrink-0`}>
          <Icon size={20} className="text-white" />
        </div>
        <div>
          <p className="text-xs text-slate-500">{label}</p>
          <p className="text-xl font-bold text-slate-900">{value}</p>
        </div>
      </div>
    </div>
  );
}
