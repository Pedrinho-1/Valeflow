import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Pencil, Trash2, CalendarClock, Eye, RotateCcw, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { formatDate, formatCurrency } from '@/lib/utils';
import { Modal } from '@/components/Modal';
import { Button } from '@/components/Button';
import { Field, Input, Textarea } from '@/components/FormFields';
import type { Competencia, CompetenciaStatus, CompetenciaHistorico } from '@/types';

const statusOrder: CompetenciaStatus[] = [
  'rascunho',
  'em_processamento',
  'em_conferencia',
  'finalizada',
];

const nextStatus: Record<CompetenciaStatus, CompetenciaStatus | null> = {
  rascunho: 'em_processamento',
  em_processamento: 'em_conferencia',
  em_conferencia: 'finalizada',
  finalizada: null,
};

export default function CompetenciasPage() {
  const queryClient = useQueryClient();
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [historicoModal, setHistoricoModal] = useState<Competencia | null>(null);
  const [reabrirModal, setReabrirModal] = useState<Competencia | null>(null);
  const [justificativa, setJustificativa] = useState('');

  const { data: competencias = [], isLoading } = useQuery({
    queryKey: ['competencias'],
    queryFn: async () => {
      const { data } = await supabase
        .from('competencias')
        .select('*')
        .order('created_at', { ascending: false });
      return (data ?? []) as Competencia[];
    },
  });

  const { data: historico = [] } = useQuery({
    queryKey: ['historico', historicoModal?.id],
    queryFn: async () => {
      if (!historicoModal) return [];
      const { data } = await supabase
        .from('competencia_historico')
        .select('*')
        .eq('competencia_id', historicoModal.id)
        .order('created_at', { ascending: false });
      return (data ?? []) as CompetenciaHistorico[];
    },
    enabled: !!historicoModal,
  });

  const [formRef, setFormRef] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const validateForm = (): boolean => {
    const trimmed = formRef.trim();
    if (!trimmed) {
      setFormError('Informe a referência');
      return false;
    }
    if (!/^\d{2}\/\d{4}$/.test(trimmed)) {
      setFormError('Formato deve ser MM/AAAA');
      return false;
    }
    setFormError(null);
    return true;
  };

  const createMutation = useMutation({
    mutationFn: async (referencia: string) => {
      const { data: inserted } = await supabase
        .from('competencias')
        .insert({ referencia, status: 'rascunho' })
        .select()
        .single();
      if (inserted) {
        await supabase.from('competencia_historico').insert({
          competencia_id: inserted.id,
          acao: 'criada',
          status_novo: 'rascunho',
          detalhe: `Competência ${referencia} criada.`,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['competencias'] });
      setModalOpen(false);
      setFormRef('');
      setFormError(null);
    },
  });

  const ativarMutation = useMutation({
    mutationFn: async (comp: Competencia) => {
      await supabase.from('competencias').update({ ativa: false }).eq('ativa', true);
      await supabase.from('competencias').update({ ativa: true }).eq('id', comp.id);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['competencias'] }),
  });

  const avancarStatusMutation = useMutation({
    mutationFn: async (comp: Competencia) => {
      const next = nextStatus[comp.status];
      if (!next) return;
      await supabase
        .from('competencias')
        .update({ status: next, updated_at: new Date().toISOString() })
        .eq('id', comp.id);
      await supabase.from('competencia_historico').insert({
        competencia_id: comp.id,
        acao: 'status_alterado',
        status_anterior: comp.status,
        status_novo: next,
      });
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['competencias'] }),
  });

  const reabrirMutation = useMutation({
    mutationFn: async (comp: Competencia) => {
      await supabase
        .from('competencias')
        .update({
          status: 'em_conferencia',
          justificativa_reabertura: justificativa,
          updated_at: new Date().toISOString(),
        })
        .eq('id', comp.id);
      await supabase.from('competencia_historico').insert({
        competencia_id: comp.id,
        acao: 'reaberta',
        status_anterior: 'finalizada',
        status_novo: 'em_conferencia',
        justificativa: justificativa,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['competencias'] });
      setReabrirModal(null);
      setJustificativa('');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await supabase.from('competencias').delete().eq('id', id);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['competencias'] }),
  });

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      createMutation.mutate(formRef.trim());
    }
  };

  const isFinalizada = (status: CompetenciaStatus) => status === 'finalizada';

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-10 w-10 border-4 border-slate-200 border-t-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Competências</h1>
          <p className="text-sm text-slate-500 mt-0.5">{competencias.length} competência(s)</p>
        </div>
        <Button onClick={() => { setFormRef(''); setFormError(null); setEditingId(null); setModalOpen(true); }}>
          <Plus size={18} /> Nova Competência
        </Button>
      </div>

      {competencias.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 px-6 py-16 text-center text-slate-400">
          <CalendarClock size={40} className="mx-auto mb-3 text-slate-300" />
          <p>Nenhuma competência criada ainda.</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50">
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Referência</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Funcionários</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Calculado</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Complementar</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Divergências</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Criada em</th>
                  <th className="text-right px-6 py-3 font-semibold text-slate-600">Ações</th>
                </tr>
              </thead>
              <tbody>
                {competencias.map((comp) => (
                  <tr key={comp.id} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{comp.referencia}</span>
                        {comp.ativa && (
                          <span className="text-xs bg-blue-600 text-white px-2 py-0.5 rounded-full font-semibold">Ativa</span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-3 text-slate-600">{comp.total_funcionarios}</td>
                    <td className="px-6 py-3 text-slate-600">{formatCurrency(comp.total_calculado)}</td>
                    <td className="px-6 py-3 text-slate-600">{formatCurrency(comp.total_complementar)}</td>
                    <td className="px-6 py-3 text-slate-600">{comp.total_divergencias}</td>
                    <td className="px-6 py-3 text-slate-500">{formatDate(comp.created_at)}</td>
                    <td className="px-6 py-3">
                      <div className="flex items-center justify-end gap-1.5">
                        {!comp.ativa && !isFinalizada(comp.status) && (
                          <button
                            onClick={() => ativarMutation.mutate(comp)}
                            className="text-xs text-blue-600 hover:bg-blue-50 px-2 py-1 rounded transition-colors font-medium"
                            title="Ativar competência"
                          >
                            Ativar
                          </button>
                        )}
                        {!isFinalizada(comp.status) && nextStatus[comp.status] && (
                          <button
                            onClick={() => avancarStatusMutation.mutate(comp)}
                            className="text-xs text-emerald-600 hover:bg-emerald-50 px-2 py-1 rounded transition-colors font-medium flex items-center gap-1"
                            title="Avançar status"
                          >
                            <CheckCircle2 size={14} />
                            Avançar
                          </button>
                        )}
                        <button
                          onClick={() => setHistoricoModal(comp)}
                          className="text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg p-1.5 transition-colors"
                          title="Histórico"
                        >
                          <Eye size={16} />
                        </button>
                        {isFinalizada(comp.status) && (
                          <button
                            onClick={() => { setReabrirModal(comp); setJustificativa(''); }}
                            className="text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg p-1.5 transition-colors"
                            title="Reabrir competência"
                          >
                            <RotateCcw size={16} />
                          </button>
                        )}
                        {comp.status === 'rascunho' && comp.total_funcionarios === 0 && (
                          <button
                            onClick={() => {
                              if (confirm('Excluir esta competência?')) deleteMutation.mutate(comp.id);
                            }}
                            className="text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg p-1.5 transition-colors"
                            title="Excluir"
                          >
                            <Trash2 size={16} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Nova Competência */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Nova Competência">
        <form onSubmit={onSubmit} className="space-y-4">
          <Field label="Referência (MM/AAAA)" error={formError ?? undefined}>
            <Input
              value={formRef}
              onChange={(e) => { setFormRef(e.target.value); if (formError) setFormError(null); }}
              placeholder="09/2026"
            />
          </Field>
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>Cancelar</Button>
            <Button type="submit" disabled={createMutation.isPending}>
              {createMutation.isPending ? 'Criando...' : 'Criar'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Modal Histórico */}
      <Modal open={!!historicoModal} onClose={() => setHistoricoModal(null)} title={`Histórico — ${historicoModal?.referencia ?? ''}`}>
        {historico.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-8">Nenhum registro de histórico.</p>
        ) : (
          <div className="space-y-3">
            {historico.map((h) => (
              <div key={h.id} className="border border-slate-200 rounded-lg p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-semibold text-slate-700 capitalize">{h.acao.replace(/_/g, ' ')}</span>
                  <span className="text-xs text-slate-400">{formatDate(h.created_at)}</span>
                </div>
                {h.status_anterior && h.status_novo && (
                  <p className="text-xs text-slate-500 mb-1">
                    {h.status_anterior} → {h.status_novo}
                  </p>
                )}
                {h.detalhe && <p className="text-xs text-slate-500">{h.detalhe}</p>}
                {h.justificativa && (
                  <p className="text-xs text-amber-600 mt-1">Justificativa: {h.justificativa}</p>
                )}
              </div>
            ))}
          </div>
        )}
      </Modal>

      {/* Modal Reabrir */}
      <Modal open={!!reabrirModal} onClose={() => setReabrirModal(null)} title={`Reabrir Competência — ${reabrirModal?.referencia ?? ''}`}>
        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-800">
            A competência voltará para o status <strong>Em Conferência</strong>. A justificativa é obrigatória e será registrada no histórico.
          </div>
          <Field label="Justificativa *">
            <Textarea
              value={justificativa}
              onChange={(e) => setJustificativa(e.target.value)}
              rows={4}
              placeholder="Descreva o motivo da reabertura..."
            />
          </Field>
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setReabrirModal(null)}>Cancelar</Button>
            <Button
              variant="danger"
              disabled={!justificativa.trim() || reabrirMutation.isPending}
              onClick={() => reabrirMutation.mutate(reabrirModal!)}
            >
              {reabrirMutation.isPending ? 'Reabrindo...' : 'Reabrir Competência'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
