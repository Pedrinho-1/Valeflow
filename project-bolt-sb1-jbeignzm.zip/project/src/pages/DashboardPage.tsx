import { useQuery } from '@tanstack/react-query';
import {
  Users,
  Building2,
  Calculator,
  DollarSign,
  AlertTriangle,
  TrendingUp,
  CalendarClock,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { formatCurrency } from '@/lib/utils';
import { StatusBadge, TipoExcecaoBadge } from '@/components/StatusBadge';

export default function DashboardPage() {
  const { data: competenciaAtiva, isLoading } = useQuery({
    queryKey: ['competencia-ativa'],
    queryFn: async () => {
      const { data } = await supabase
        .from('competencias')
        .select('*')
        .eq('ativa', true)
        .maybeSingle();
      return data;
    },
  });

  const { data: excecoesPendentes } = useQuery({
    queryKey: ['excecoes-pendentes-dashboard'],
    queryFn: async () => {
      if (!competenciaAtiva) return [];
      const { data } = await supabase
        .from('excecoes')
        .select('*')
        .eq('competencia_id', competenciaAtiva.id)
        .eq('status', 'pendente')
        .order('created_at', { ascending: false })
        .limit(10);
      return data ?? [];
    },
    enabled: !!competenciaAtiva,
  });

  const { data: funcionariosComProblema } = useQuery({
    queryKey: ['funcionarios-problema-dashboard'],
    queryFn: async () => {
      if (!competenciaAtiva) return [];
      const { data } = await supabase
        .from('funcionarios')
        .select('nome, cpf, unidade, valor_calculado, valor_pago, valor_complementar, status')
        .eq('competencia_id', competenciaAtiva.id)
        .neq('status', 'ok')
        .order('valor_complementar', { ascending: false })
        .limit(8);
      return data ?? [];
    },
    enabled: !!competenciaAtiva,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-10 w-10 border-4 border-slate-200 border-t-blue-600" />
      </div>
    );
  }

  if (!competenciaAtiva) {
    return (
      <div className="space-y-6">
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-xl p-6 text-white shadow-lg">
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-slate-300 mt-1">Visão geral da conciliação de Vale-Transporte</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 px-6 py-16 text-center">
          <CalendarClock size={48} className="mx-auto mb-4 text-slate-300" />
          <h3 className="text-lg font-semibold text-slate-700 mb-2">Nenhuma competência ativa</h3>
          <p className="text-sm text-slate-400">
            Crie e ative uma competência em "Competências" para visualizar os dados do dashboard.
          </p>
        </div>
      </div>
    );
  }

  const stats = [
    {
      label: 'Funcionários',
      value: competenciaAtiva.total_funcionarios,
      icon: Users,
      color: 'bg-blue-600',
      sub: 'Total importado',
    },
    {
      label: 'Unidades',
      value: competenciaAtiva.total_unidades,
      icon: Building2,
      color: 'bg-cyan-600',
      sub: 'Unidades distintas',
    },
    {
      label: 'Total Calculado',
      value: formatCurrency(competenciaAtiva.total_calculado),
      icon: Calculator,
      color: 'bg-teal-600',
      sub: 'Dias ativos x passagens x tarifa',
    },
    {
      label: 'Total Pago',
      value: formatCurrency(competenciaAtiva.total_pago),
      icon: DollarSign,
      color: 'bg-indigo-600',
      sub: 'Valor pago informado',
    },
    {
      label: 'A Complementar',
      value: formatCurrency(competenciaAtiva.total_complementar),
      icon: TrendingUp,
      color: 'bg-amber-600',
      sub: 'Diferença calculado - pago',
    },
    {
      label: 'Exceções Pendentes',
      value: excecoesPendentes?.length ?? 0,
      icon: AlertTriangle,
      color: 'bg-red-600',
      sub: 'Aguardando resolução',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-xl p-6 text-white shadow-lg">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <div className="flex items-center gap-3 mt-2">
          <span className="text-slate-300 text-sm">Competência ativa:</span>
          <span className="bg-blue-600 px-3 py-1 rounded-lg text-sm font-semibold">
            {competenciaAtiva.referencia}
          </span>
          <StatusBadge status={competenciaAtiva.status} />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {stats.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.label}
              className="bg-white rounded-xl p-5 shadow-sm border border-slate-200 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-slate-500 font-medium">{card.label}</p>
                  <p className="text-2xl font-bold text-slate-900 mt-1">{card.value}</p>
                  <p className="text-xs text-slate-400 mt-1">{card.sub}</p>
                </div>
                <div className={`w-12 h-12 rounded-lg ${card.color} flex items-center justify-center flex-shrink-0`}>
                  <Icon size={24} className="text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {(funcionariosComProblema?.length ?? 0) > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200">
            <h2 className="text-lg font-bold text-slate-900">Funcionários com Problemas</h2>
            <p className="text-sm text-slate-500 mt-0.5">Registros com divergência ou complemento</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50">
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Nome</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Unidade</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Calculado</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Pago</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Complementar</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Status</th>
                </tr>
              </thead>
              <tbody>
                {funcionariosComProblema!.map((f) => (
                  <tr key={f.cpf ?? f.nome} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="px-6 py-3 text-slate-700 font-medium">{f.nome ?? '—'}</td>
                    <td className="px-6 py-3 text-slate-600">{f.unidade ?? '—'}</td>
                    <td className="px-6 py-3 text-slate-600">{formatCurrency(f.valor_calculado)}</td>
                    <td className="px-6 py-3 text-slate-600">{formatCurrency(f.valor_pago)}</td>
                    <td className="px-6 py-3 font-semibold text-amber-600">
                      {formatCurrency(f.valor_complementar)}
                    </td>
                    <td className="px-6 py-3"><StatusBadge status={f.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {(excecoesPendentes?.length ?? 0) > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200">
            <h2 className="text-lg font-bold text-slate-900">Exceções Pendentes</h2>
            <p className="text-sm text-slate-500 mt-0.5">Fila de trabalho atual</p>
          </div>
          <div className="divide-y divide-slate-100">
            {excecoesPendentes!.map((exc) => (
              <div key={exc.id} className="px-6 py-3 flex items-center justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <TipoExcecaoBadge tipo={exc.tipo} />
                    <span className="text-sm font-medium text-slate-700 truncate">
                      {exc.funcionario_nome ?? '—'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 truncate">{exc.descricao}</p>
                </div>
                <span className="text-sm font-semibold text-slate-600 flex-shrink-0">
                  {exc.valor_afetado > 0 ? formatCurrency(exc.valor_afetado) : ''}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
