import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Pencil, Trash2, Ticket, Search } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { formatCurrency } from '@/lib/utils';
import { parseCurrency } from '@/lib/parsers';
import { StatusBadge } from '@/components/StatusBadge';
import { Modal } from '@/components/Modal';
import { Button } from '@/components/Button';
import { Field, Input, Select } from '@/components/FormFields';
import type { Tarifa } from '@/types';

const ufs = ['AC', 'AL', 'AM', 'AP', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MG', 'MS', 'MT', 'PA', 'PB', 'PE', 'PI', 'PR', 'RJ', 'RN', 'RO', 'RR', 'RS', 'SC', 'SE', 'SP', 'TO'];

function formatBrlInput(value: string): string {
  const parsed = parseCurrency(value);
  return parsed > 0 ? formatCurrency(parsed) : value;
}

type FormState = {
  uf: string;
  municipio: string;
  valor: string;
  trechos_diarios: string;
  valor_diario_override: string;
  ativa: boolean;
};

type FormErrors = Partial<Record<keyof FormState, string>>;

function validateForm(form: FormState): FormErrors {
  const errors: FormErrors = {};
  if (!form.uf.trim()) errors.uf = 'Informe a UF ou unidade';
  if (!form.valor.trim()) errors.valor = 'Informe o valor por dia';
  const dias = parseInt(form.trechos_diarios, 10);
  if (!form.trechos_diarios.trim()) errors.trechos_diarios = 'Informe a quantidade de dias';
  else if (isNaN(dias) || dias < 1) errors.trechos_diarios = 'Informe ao menos 1 dia';
  return errors;
}

const emptyForm: FormState = {
  uf: 'SP',
  municipio: '',
  valor: '',
  trechos_diarios: '1',
  valor_diario_override: '',
  ativa: true,
};

export default function TarifasPage() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [errors, setErrors] = useState<FormErrors>({});

  const { data: tarifas = [], isLoading } = useQuery({
    queryKey: ['tarifas'],
    queryFn: async () => {
      const { data, error } = await supabase.from('tarifas').select('*').order('uf');
      if (error) throw error;
      return (data ?? []) as Tarifa[];
    },
  });

  useEffect(() => {
    if (!modalOpen) return;
    const dias = parseInt(form.trechos_diarios, 10) || 0;
    const valor = parseCurrency(form.valor);
    const override = parseCurrency(form.valor_diario_override);
    const calculo = override > 0 ? override : valor * dias;
    setValorDiario(calculo);
  }, [form.valor, form.trechos_diarios, form.valor_diario_override, modalOpen]);

  const [valorDiario, setValorDiario] = useState(0);

  const saveMutation = useMutation({
    mutationFn: async (data: FormState) => {
      const regraNome = `${data.uf}${data.municipio ? ' / ' + data.municipio.trim() : ''}`;
      const payload = {
        regra_nome: regraNome,
        uf: data.uf.trim().toUpperCase(),
        municipio: data.municipio.trim() || null,
        valor: parseCurrency(data.valor),
        trechos_diarios: parseInt(data.trechos_diarios, 10),
        valor_diario_override: parseCurrency(data.valor_diario_override) || null,
        ativa: data.ativa,
        codigo_linha: null,
        descricao: regraNome,
        concessionaria: null,
        updated_at: new Date().toISOString(),
      };

      const query = editingId
        ? supabase.from('tarifas').update(payload).eq('id', editingId)
        : supabase.from('tarifas').insert(payload);
      const { error } = await query;
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tarifas'] });
      setModalOpen(false);
      setFormError(null);
    },
    onError: (error: Error) => setFormError(error.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('tarifas').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['tarifas'] }),
  });

  const handleOpenAdd = () => {
    setForm(emptyForm);
    setErrors({});
    setEditingId(null);
    setFormError(null);
    setModalOpen(true);
  };

  const handleOpenEdit = (tarifa: Tarifa) => {
    setForm({
      uf: tarifa.uf,
      municipio: tarifa.municipio ?? '',
      valor: formatBrlInput(String(tarifa.valor)),
      trechos_diarios: String(tarifa.trechos_diarios ?? 1),
      valor_diario_override: tarifa.valor_diario_override ? formatBrlInput(String(tarifa.valor_diario_override)) : '',
      ativa: tarifa.ativa,
    });
    setErrors({});
    setEditingId(tarifa.id);
    setFormError(null);
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateForm(form);
    setErrors(validation);
    if (Object.keys(validation).length > 0) return;
    saveMutation.mutate(form);
  };

  const updateField = (field: keyof FormState, value: string | boolean) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const filtered = tarifas.filter((tarifa) => {
    const query = search.toLowerCase();
    return (
      tarifa.uf.toLowerCase().includes(query) ||
      (tarifa.municipio ?? '').toLowerCase().includes(query) ||
      (tarifa.regra_nome ?? '').toLowerCase().includes(query)
    );
  });

  if (isLoading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-10 w-10 border-4 border-slate-200 border-t-blue-600" /></div>;
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Gestão de Tarifas</h1>
          <p className="text-sm text-slate-500 mt-0.5">Regras e valores de transporte</p>
        </div>
        <Button onClick={handleOpenAdd}><Plus size={18} /> Nova Tarifa</Button>
      </div>

      <div className="relative">
        <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <Input className="pl-10" placeholder="Buscar por UF ou município..." value={search} onChange={(event) => setSearch(event.target.value)} />
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        {filtered.length === 0 ? (
          <div className="px-6 py-16 text-center text-slate-400">
            <Ticket size={40} className="mx-auto mb-3 text-slate-300" />
            <p>Nenhuma regra de tarifa encontrada.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50">
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">UF / Unidade</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Dias</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Valor Diário Calculado</th>
                  <th className="text-left px-6 py-3 font-semibold text-slate-600">Status</th>
                  <th className="text-right px-6 py-3 font-semibold text-slate-600">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((tarifa) => {
                  const diario = tarifa.valor_diario_override ?? Number(tarifa.valor) * Number(tarifa.trechos_diarios ?? 1);
                  return (
                    <tr key={tarifa.id} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="px-6 py-3 text-slate-700 font-medium">{tarifa.uf}{tarifa.municipio ? ` / ${tarifa.municipio}` : ''}</td>
                      <td className="px-6 py-3 text-slate-600">{tarifa.trechos_diarios}</td>
                      <td className="px-6 py-3 font-semibold text-teal-700">{formatCurrency(diario)}</td>
                      <td className="px-6 py-3"><StatusBadge status={tarifa.ativa ? 'ativa' : 'inativa'} /></td>
                      <td className="px-6 py-3">
                        <div className="flex items-center justify-end gap-2">
                          <button onClick={() => handleOpenEdit(tarifa)} className="text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg p-1.5 transition-colors" title="Editar"><Pencil size={16} /></button>
                          <button onClick={() => { if (confirm('Excluir esta regra de tarifa?')) deleteMutation.mutate(tarifa.id); }} className="text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg p-1.5 transition-colors" title="Excluir"><Trash2 size={16} /></button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? 'Editar Tarifa' : 'Nova Tarifa'}>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="UF / Unidade" error={errors.uf}>
              <Select value={form.uf} onChange={(e) => updateField('uf', e.target.value)}>
                {ufs.map((uf) => <option key={uf} value={uf}>{uf}</option>)}
              </Select>
            </Field>
            <Field label="Município (opcional)" error={errors.municipio}>
              <Input value={form.municipio} onChange={(e) => updateField('municipio', e.target.value)} placeholder="Salvador" />
            </Field>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Valor por Dia (R$)" error={errors.valor}>
              <Input
                value={form.valor}
                onChange={(e) => updateField('valor', e.target.value)}
                onBlur={(e) => updateField('valor', formatBrlInput(e.target.value))}
                inputMode="decimal"
                placeholder="R$ 5,90"
              />
            </Field>
            <Field label="Dias" error={errors.trechos_diarios}>
              <Input
                type="number"
                min="1"
                step="1"
                value={form.trechos_diarios}
                onChange={(e) => updateField('trechos_diarios', e.target.value)}
                placeholder="1"
              />
            </Field>
          </div>

          <Field label="Valor Diário Fixo / Override (R$)" error={errors.valor_diario_override}>
            <Input
              value={form.valor_diario_override}
              onChange={(e) => updateField('valor_diario_override', e.target.value)}
              onBlur={(e) => updateField('valor_diario_override', e.target.value ? formatBrlInput(e.target.value) : '')}
              inputMode="decimal"
              placeholder="Opcional — ex: R$ 11,20"
            />
          </Field>

          <div className="rounded-lg bg-slate-50 border border-slate-200 px-4 py-3 text-sm text-slate-600">
            Valor diário calculado: <strong className="text-teal-700">{formatCurrency(valorDiario)}</strong>
            {parseCurrency(form.valor_diario_override) > 0 && <span className="text-xs text-slate-400 ml-2">(override aplicado)</span>}
          </div>

          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input
              type="checkbox"
              checked={form.ativa}
              onChange={(e) => updateField('ativa', e.target.checked)}
              className="rounded border-slate-300"
            />
            Tarifa ativa
          </label>

          {formError && <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{formError}</p>}

          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>Cancelar</Button>
            <Button type="submit" disabled={saveMutation.isPending}>{saveMutation.isPending ? 'Salvando...' : 'Salvar'}</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
